    // for (int i = 0; i < N; i++)
    // {
    //     matrizCiudad[i][i] = 0; // Inicializar la diagonal con ceros
    // }